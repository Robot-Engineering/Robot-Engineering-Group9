import os
import xlrd
import openpyxl as ol
from openpyxl.styles import PatternFill
import xlwt
file_name=[]
all=os.walk('testdat')
for path,dir,filelist in all:
    for filename in filelist:
        if filename.endswith('jpg'):
            file_name.append(filename)
for i in range(len(file_name)):
    file_name[i]=file_name[i].strip('.jpg')
print(file_name)          
data=xlrd.open_workbook('testdat\studentdata.xlsx')
table=data.sheet_by_name('Sheet1')
tabledata=[]
rowscount=table.nrows
colscount=table.ncols
for j in range(1,rowscount):
    tabledata.append(str(int(table.cell_value(j,1))))
print(tabledata)
xuehao=[]
for num in tabledata:
    if num not in file_name:
        xuehao.append(num)
gaoliang=[]
for nums in xuehao:
    for element in range(1,rowscount):
        if int(nums)  in table.row_values(element):
            gaoliang.append(int(element))
print(gaoliang)
wb=ol.load_workbook('testdat\studentdata.xlsx')
ws=wb.active
for i in gaoliang:
    bgfill=PatternFill(fill_type='solid',fgColor='FFFF00')
    ws.row_dimensions[i+1].fill=bgfill
wb.save('testdat\studentdata.xlsx')
    




            
            
    
        
        
        


    




        
    