import tkinter as tk
from tkinter import ttk
from PIL import Image,ImageTk
def charu(*args):
    if(xl.get()=='张三(101)'):
        load=Image.open('101.jpg')
    elif(xl.get()=='李四(102)'):
        load=Image.open('102.jpg')
    elif(xl.get()=='王五(103)'):
        load=Image.open('103.jpg')
    render=ImageTk.PhotoImage(load)
    img=tk.Label(photo,image=render)
    img.image=render
    img.place(x=500,y=200)
photo=tk.Tk()
photo.title('photo')
photo.geometry('500x300')
xl=ttk.Combobox(photo)
xl.pack()
xl['value']=['张三(101)','李四(102)','王五(103)']
xl.bind('<<ComboboxSelected>>',charu)
photo.mainloop()
