import pymysql
conn=pymysql.connect(host='127.0.0.1',port=3306,user='root',password='pythonyyds',db='task')
cursor=conn.cursor()          
sql1='create table users(goods varchar(32),price int,buyer varchar(32),dispatcher varchar(32),address varchar(32),estimatedtime varchar(32),actualtime varchar(32),status varchar(32))engine=innodb default charset=utf8;'
cursor.execute(sql1)
sql2='create table orders(producer varchar(32),model varchar(32),quantity int,price int,ordertime varchar(32),finishedtime varchar(32))engine=innodb default charset=utf8;'
cursor.execute(sql2)
sql3='create table information(developers varchar(32),model varchar(32),productiondate varchar(32),function varchar(32),Applicationscenarios varchar(32),workhours int)engine=innodb default charset=utf8;'
cursor.execute(sql3)
sql2_='''insert into orders(producer,model,quantity,price,ordertime,finishedtime) values('P1','M1',2,50000,'2020/1/1','2020/2/3'),('P2','M2',3,10000,'2020/4/5','2020/5/1'),('P3','M3',1,100000,'2020/5/6','2020/6/20');'''
cursor.execute(sql2_)
sql3_='''insert into information(developers,model,productiondate,function,Applicationscenarios,workhours) values('D1','M1','2019/10/5','long distance transport','campus',10),('D2','M2','2018/2/2','climb the stairs','bulidings',6);'''
cursor.execute(sql3_)
sql_1='''insert into users(goods,price,buyer,dispatcher,address,estimatedtime,actualtime,status) values('pen',10,'Alex','robot2','123','2020/12/24','2020/12/25','undelivered');'''
cursor.execute(sql_1)  
sql_2='''insert into users(goods,price,buyer,dispatcher,address,estimatedtime,actualtime,status) values('book',20,'Tom','robot1','443','2020/12/25','2020/12/25','delivered');'''
cursor.execute(sql_2)
sql_3='select * from users'
cursor.execute(sql_3)
sql_4='''delete from users where status='delivered';'''
cursor.execute(sql_4)
conn.commit()
cursor.close()
conn.close()