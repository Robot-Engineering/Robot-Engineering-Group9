import turtle as t
class DrawLine:
    def __init__(self,l):
        self.lens=l
    def show(self):
        t.forward(self.lens)
class DrawCircle:
    def __init__(self,r):
        self.rad=r
    def show(self):
        t.circle(self.rad)
class DrawRect:
    def __init__(self,a,b):
        self.chang=a
        self.kuan=b
    def show(self):
        t.forward(self.chang)
        t.right(90)
        t.forward(self.kuan)
        t.right(90)
        t.forward(self.chang)
        t.right(90)
        t.forward(self.kuan)
#        
        
        
        
        
    
        
    

