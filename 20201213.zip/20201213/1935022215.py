# _*_coding.utf-8_*_
# 开发人员:Rin
# 开发时间:2020/12/13 09:56
# 文件名称:1935022215.py
# 开发工具:PyCharm
import turtle


class Draw():
    class Drawline():
        def drawline(self):
            distance = int(input('请输入长度'))
            turtle.begin_fill()
            turtle.forward(distance)
            turtle.end_fill()
            turtle.exitonclick()

    class Drawcircle():
        def drawcircle(self):
            radius = int(input('请输入半径'))
            turtle.circle(radius)
            turtle.exitonclick()

    class Drawrect():
        def drawrect(self):
            brad = turtle.Turtle()
            l = int(input('请输入正方形长度'))

            for i in range(4):
                brad.right(90)
                brad.forward(l)
            turtle.exitonclick()

    def choice(self):
        key = int(input('请选择所要绘制的图形:1为直线 2为圆 3为矩形'))
        if key == 1:
            Draw().Drawline().drawline()
        elif key == 2:
            Draw().Drawcircle().drawcircle()

        elif key == 3:
            Draw().Drawrect().drawrect()


example = Draw()
example.choice()